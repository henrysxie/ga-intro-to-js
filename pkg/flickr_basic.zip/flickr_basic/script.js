"use strict";

var imageCount = 20;
var indexCounter = 0;

var container = $('#container');
var viewport = $('#viewport');

function showImage(index){
  // whats the offset? hint: use the image number and the viewport width

  var viewportWidth = -$(window).width();

  var offset = viewportWidth * index;

  container.css('margin-left', offset);

}

function nextImage(){
  indexCounter = indexCounter + 1;
  
  if(indexCounter > imageCount){
    indexCounter = 0;
  }
  
  showImage(indexCounter);

  // if indexcounter is the same as imagecount
  // reset the indexcounter to 0

  // increment the indexcounter
  // call showImage with the indexCounter
}

function apiSuccess(result){
  // debugger;
  var photos = result['items'];
  console.log(photos);

  for (var i = 0; i < photos.length; i++) {
    console.log(photos[i]['title']);
    console.log(photos[i]['media']['m']);

    var myDiv = $("<div class='post'></div>");
    var myImage = $("<img src='" + photos[i]['media']['m'] + "' />");
    myDiv.append(myImage);
    container.append(myDiv);
    myDiv.css('width', $(window).width());
  };

  window.setInterval(nextImage, 1500);
}

var ajaxSettings = {
  // The url to flickrs api
  url: 'http://api.flickr.com/services/feeds/photos_public.gne?format=json&jsoncallback=?',
  // The format we want it in
  dataType: 'jsonp',
  // The function to execute when the api has finished loading
  success: apiSuccess,
};

$.ajax(ajaxSettings);